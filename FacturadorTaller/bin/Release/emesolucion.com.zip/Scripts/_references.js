﻿/// <reference path="modernizr-2.6.2.js" />
/// <autosync enabled="true" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
/// <reference path="jquery-1.12.4.js" />
/// <reference path="jquery-ui-1.12.1.js" />
